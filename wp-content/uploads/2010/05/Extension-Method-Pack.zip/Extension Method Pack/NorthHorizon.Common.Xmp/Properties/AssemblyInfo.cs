﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("North Horizon Extension Method Pack")]
[assembly: AssemblyCompany("North Horizon")]
[assembly: AssemblyProduct("Extension Method Pack")]
[assembly: AssemblyCopyright("http://northhorizon.net/license/")]

[assembly: ComVisible(false)]

[assembly: Guid("6205fc88-052d-486d-9be3-9be8e653ad46")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: CLSCompliant(true)]

[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA2210:AssembliesShouldHaveValidStrongNames")]